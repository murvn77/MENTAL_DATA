/* JAVASCRIPT */

let descripcion = "<i>Mental Data es una plataforma que ofrece herramientas digitales para la salud mental</i>"
descripcion = "<p>"+descripcion+"</p>"
document.write(descripcion)